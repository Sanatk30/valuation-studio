# Valuation Studio

Interactive financial modeling & valuation workspace. Enter your assumptions once — every method
recalculates live, and the whole model exports to Excel **with live formulas** (banker
conventions: blue = input, black = formula, green = cross-sheet link).

## The workspace

- **Left rail** — jump between methods (press `1`–`9`); collapses to icons.
- **Ticker strip** — always-visible live tape: blended implied value, market price, and every
  method's implied share price. Prices tween and flash green/red as you drag assumptions;
  click any ticker to open that method.
- **Assumptions dock** (right, press `A`) — live sliders on every view: *Key Levers* (the
  highest-torque assumptions) on top, then the active method's panels, then Display & Period
  (currency, unit, start year, fiscal basis). Drag anything and the entire workspace —
  ticker, hero numbers, tables, charts, sensitivities — flows to the new answer. While you
  drag, every chart holds a faint dashed trace of where its series *were*, so the move is
  visible; **click any bar or line on a chart** and the dock opens on the assumption that
  drives it, flashing the slider.
- **Top bar** — company name (which doubles as a live listing search), Bear/Base/Bull
  scenario, Enter Data, Companies, Reset and the Excel export menu.

## Run it

```bash
npm install
npm run dev        # opens on http://localhost:5173
```

`npm run build` produces a static bundle in `dist/` you can host anywhere.
`npm test` runs the full verification suite (engine math + Excel formula recalculation).

## What's inside

| Tab | Contents |
| --- | --- |
| **Summary** | Football field across all methods, blended implied price, key outputs |
| **DCF** | 3E-layout unlevered build: three **back-cast historical** columns + LTM + projection with CAGR columns, % growth / % margin sub-rows, then Enterprise Value and Implied Equity Value & Share Price side by side under both terminal-value methods, terminal-value cross-checks and the assumptions block. FCFE (→ equity at cost of equity) beneath. Full **cost-of-capital** section: CAPM + Hamada build, the peer set's unlevered beta relevered at the target structure (reference), and a capital-structure × cost-of-debt WACC surface. 5 sensitivity grids |
| **3-Statement** | Linked IS / CF / BS with debt & cash schedule, dividend policy, balance check (interest on opening balances — no circular refs) |
| **Ratios** | 55 ratios, **Past or Future**: Past (default) covers the **past N years** (History slider, 2–10, default 5) ending at the LTM year, back-cast from today's balance sheet and the driver set (fades extended backwards; lands exactly on current debt/cash/PP&E); Future runs the same set over the projection horizon. Yearly/half-yearly/quarterly; click any ratio row for an inline Bear/Base/Bull trend chart |
| **LBO** | Sources & uses with transaction + financing fees (amortized tax shield); senior + mezzanine (optional PIK); mandatory amortization + cash sweep with a minimum-cash floor; credit stats; value-creation bridge (fees / EBITDA growth / multiple / deleveraging); IRR + MOIC + Excel IRR() cross-check; LBO-floor valuation (max price at a hurdle IRR); entry×exit and hold×exit IRR grids |
| **Comps & Regression** | Bottom-up comparable companies in the style of the *Investment Banking, 3E* template: every peer is a full **input page** of reported financials (LTM stub bridge, non-recurring adjustments, treasury-method dilution, two-column balance sheet with its check, consensus estimates), grouped into named **tiers**. Views: Benchmarking 1 (market valuation, LTM statistics, margins, growth), Benchmarking 2 (returns, leverage, coverage, ratings), Trading multiples (LTM + NFY + NFY+1, tiered with Mean/Median/High/Low), List, and the input pages themselves. Plus quartile ranges and the OLS regression of EV/EBITDA on growth |
| **Precedent** | Bottom-up precedent transactions in the *Investment Banking, 3E* layout: every deal is a full **input page** — the target's reported financials (LTM stub bridge, non-recurring adjustments, treasury-method dilution) priced at the **offer** rather than at the market, plus the offer-price build (cash + exchange ratio x acquirer price), the EV bridge and premiums paid at 1 / 7 / 30 days. Views: Output (transaction multiples, LTM EBITDA margin, premiums, with Mean/Median/High/Low), List, and the input pages. Quartile ranges and premia analysis on the current share price |
| **IPO** | P/E or EV/EBITDA pricing basis, IPO discount, primary/secondary/greenshoe structure, underwriting fees, use of proceeds, pro-forma EPS dilution, fair-value uplift, ownership split |
| **Charts** | Pick-any-combination gallery of 22 live charts (operating, DCF, LBO, 3-statement, market) with per-group all/none and click-to-expand — selection persists. Dashed **Bear/Bull ghost overlays** show the scenario range on every scenario-sensitive chart (toggle in the gallery header or Display & Period); year-axis charts share a **synced crosshair**; reference annotations mark the average margin, LBO cash floor & exit year, entry multiple and market price |

Every method tab also carries a **bottom-up build** in banker style: DCF shows the full
FCFF/FCFE builds with discount periods/factors, cumulative PV and terminal-value cross-checks
(implied perpetuity growth ↔ implied exit multiple); LBO has a returns-analysis table (exit any
year → equity → MOIC/IRR); Comps/Precedent walk multiple × metric → EV → equity → per share at
the 25th/median/75th percentile; IPO builds the offer price step by step.

**Companies** (top bar) saves the complete assumption set under the company name — switch
between saved companies with one click. Once saved, every edit auto-updates the entry.

**Company search** lives in the company-name field itself: type a name or ticker
(RELIANCE.NS, AAPL, TCS.BO…), pick the listing, review exactly what was reported and how it
maps into the model (units auto-convert, e.g. INR → Cr), then apply. Works under
`npm run dev` (the dev server proxies Yahoo, which sends no CORS headers).

In the **Regression Lab** data table, the built-in variables (multiples, growth, margin,
leverage, ROE, USD size) are *derived from each peer's comps input page* and are therefore
read-only there — edit the underlying financials in Comps → Input pages and the whole table
follows. Only custom variables you add yourself are typed in directly.

The Comps tab includes the full **regression worksheet**: per-peer fitted values and
residuals, the Sxx/Sxy/Syy → slope/intercept/R²/SE build, and the multiple-to-price bridge
at ±1 standard error.

All methods share one operating driver set (revenue growth fade or per-year custom, EBITDA
margin, D&A/capex/NWC as % of revenue) — change a driver and every tab updates.

## Entering data

**The company name field is also the search bar.** Type a name: listed companies show
matching tickers underneath (name, symbol, exchange) — pick one and you get a preview of
exactly what the feed reports and how it maps into the model, and nothing changes until you
hit Apply. Type a name that isn't listed and nothing happens beyond naming the company,
which is all a private company needs.

- **Enter Data** (top bar) opens a bulk-entry form: every assumption — company, drivers
  (incl. the per-year grid with Excel row-paste), WACC, DCF, 3-statement, LBO, IPO,
  comparable companies and precedent deals — in one place, applied in one click. The JSON
  view lets you copy the whole model out (to save or share) and paste a saved set back in.
- Blue dashed cells in the statement tables are direct inputs — click and type, the model
  re-links live. Hovering any table cell magnifies it for easy reading; the cell stays
  magnified while you type.

### Three routes into a comparable company

All three fill the same input page, so you can start with one and finish with another —
fetch a listed peer, then type in the lines the feed doesn't carry.

| Route | Where | Good for |
| --- | --- | --- |
| **Search** | The peer box in the Comps dock, or the batch ticker box | Listed peers. Pulls revenue, EBITDA, D&A, capex, net income, shares, debt, cash and equity. The COGS/SG&A split, the rest of the balance sheet and CFO aren't in the feed — the page's badge says so and lists which outputs read NA until you fill them |
| **Paste** | *Paste from Excel* on any input page, or *Paste table* in the dock | A screen you already have in a spreadsheet. Two shapes: line items down / periods across for one company, or one row per company for a whole peer set. Both preview every matched row, where each column lands, and anything they couldn't place |
| **Type** | The input page, in the Comps tab or embedded in Enter Data | **Private companies** — no ticker, no feed. Every field on the page, entered by hand |

Paste is forgiving: labels are matched by synonym (`Revenue`, `Net sales`, `Less: COGS`,
`Sales (₹ Cr)` all land correctly), accounting negatives `(1,234)` and currency symbols are
understood, blank cells leave existing values alone, and rows that belong to another block
are held back rather than forced into the wrong place.

Currency (₹/$/€/£), unit (Cr/Lakh/Mn/Bn/'000), start year and fiscal basis live in the
dock's **Display & Period** panel. Assumptions, the active view and dock state persist in
the browser (localStorage); Reset restores the sample company.

## Excel export

The top-bar **Export Excel** menu downloads live-formula workbooks:

- **Full model** — Cover + Assumptions, DCF, 3 Statement, LBO, Comps (incl. regression),
  Precedent, IPO, Summary in one file.
- **Single-method files** — DCF Analysis (+ WACC), 3-Statement, LBO Analysis, Comparable
  Companies, Precedent Transactions, IPO Valuation: each is a complete standalone package with its own
  Cover, the Assumptions page, the shared DCF projection sheet **and the full 3-Statement
  model**, in the style of the classic banking templates (blue inputs / black formulas /
  green cross-sheet links). Method sheets carry the full detail: the DCF adds cumulative PV
  and terminal-value cross-checks (implied exit multiple ↔ implied perpetuity growth), the
  3-Statement a per-year ratio-analysis block, the LBO a returns-if-exited-each-year table,
  Precedent per-deal implied prices, and IPO the post-IPO ownership split.

### DCF & WACC workbook

Rebuilt in the layout of the 3E *DCF* and *WACC* sheets:

| Sheet | Contents |
| --- | --- |
| **DCF** | Historical period (back-cast) · CAGR · LTM · projection · CAGR; Sales → EBITDA → EBIT → EBIAT with % growth and % margin sub-rows; the unlevered free-cash-flow build; **Enterprise Value** and **Implied Equity Value and Share Price** side by side under both terminal-value methods; terminal-value cross-checks and implied valuation multiples; the assumptions block the model reads from; five 2-up sensitivity grids; the levered (FCFE) build and valuation beneath |
| **WACC** | Target capital structure → cost of debt → cost of equity → WACC; the comparable companies' unlevered beta table with mean/median and the relevered cross-check; a capital-structure × cost-of-debt WACC surface that relevers beta in every cell |

The historical columns are **back-cast**, not reported: growth and margin are the Year-1 rates
extended backwards, D&A / capex / NWC hold their Year-1 revenue rates, and the LTM column is the
model's own Year 0 — so LTM EBITDA on the DCF page is the same figure the LBO entry multiple and
the comps target use. The peer beta table is a blue input snapshot so the standalone DCF file
does not have to ship the comps company pages; it is a **reference** and does not drive the
discount rate, so the workbook always matches the app.

**Deliberate departure from the 3E template:** under the mid-year convention 3E's implied
perpetuity growth omits the gross-up in one branch. Here the terminal flow is grossed up by
(1+WACC)^0.5 whenever mid-year is on, so the cross-check is consistent with the discounting.

### Precedent transactions workbook

| Sheet | Contents |
| --- | --- |
| **Precedent** | The output page: date announced, acquirer, target, transaction type, purchase consideration, equity and enterprise value, EV/LTM Sales · EBITDA · EBIT, LTM EBITDA margin, equity value / LTM net income, premiums paid at 1 / 7 / 30 days — then Mean / Median / High / Low and the implied-takeover-value bridge |
| **Deal List** | Date · acquirer · target · type · target business description · equity & enterprise value · LTM sales & EBITDA |
| *&lt;Acquirer - Target&gt;* x n | One full input page per transaction |

A deal's input page **is** the comparable-company page with the target's reported financials,
priced at the offer instead of at the market — the same LTM stub bridge, non-recurring
adjustments and treasury-method share count — plus the deal-terms block: offer-price build
(cash + exchange ratio x acquirer share price), the EV bridge, the LTM transaction multiples
and the premiums paid over the unaffected share price. A saved deal set in the old typed-multiple
shape is reconstructed onto this shape at the SAME multiples and premiums, with the originals
parked on `legacyDeals`.

### Comparable companies workbook

The comps export is a multi-sheet package laid out like the 3E template, with the two
benchmarking pages leading the file:

| Sheet | Contents |
| --- | --- |
| **Benchmarking 1** | Market valuation · LTM financial statistics · profitability margins · growth rates |
| **Benchmarking 2** | General (FYE, beta) · returns on investment · leverage · coverage · credit ratings |
| **Comps Analysis** | The tiered trading-multiples page (LTM / NFY / NFY+1 on EV/Sales, EV/EBITDA, EV/EBIT, P/E, P/FCF), then the implied-share-price bridge at the 25th / median / 75th percentile |
| **List** | Company · ticker · business description · equity value · enterprise value · LTM sales & EBITDA |
| *&lt;Target&gt;* | The target's input page, driven by the shared model |
| *&lt;Peer&gt;* × n | One full input page per comparable company |

Each tier carries its own Mean and Median; an Overall block adds High and Low. Every
analysis cell is a cross-sheet link into a company page and every company page cell is a
formula off that page's blue inputs — edit a reported number and the whole file re-solves.

**Not-meaningful multiples.** A multiple on a non-positive denominator (a loss-making year,
negative free cash flow) reports **NM** rather than a negative number, and drops out of the
Mean / Median / High / Low — one peer with negative FCF can no longer drag a tier's mean
P/FCF below zero. The Excel cell is `IF(metric<=0,"NM",…)`, and AVERAGE / MEDIAN / QUARTILE /
MAX / MIN ignore the text, so the exclusion survives editing in Excel. `NA` still means the
input is absent; `NM` means it is present but not meaningful.

**Money formatting.** Analysis pages (Benchmarking 1/2, Comps Analysis, Implied Valuation,
List) print money as plain numbers — the page header already states `(₹ in Cr, …)`, and
repeating the symbol down twenty columns is noise. The currency symbol stays where it carries
information: per-share prices, and the company input pages.

**Deliberate departures from the 3E template**, all of which fix defects in the original:

- **P/FCF and FCF Yield.** The template divides *equity value* by *FCF per share* (mixing a
  total with a per-share figure) and points its estimate columns at empty cells, so both
  lines are unusable as shipped. Here P/FCF is Price ÷ FCF-per-share and FCF Yield its
  reciprocal, with the estimate columns reading real per-share inputs.
- **The dividend line** is labelled *Implied Annual Dividend Yield*, which is what the
  formula computes and what Benchmarking 2 reports; the template labels it "per share".
- **The EV bridge** reads debt, preferred, NCI and cash off the current balance-sheet
  column instead of re-entering them, so the balance check validates the bridge too.
- **Gross profit** reports NA for a model-derived target: the driver set carries no
  COGS/SG&A split, and none is invented. Supply `comps.targetGrossMarginPct` to fill it in.

Every figure is a real formula chained to the blue input cells. Edit any input in Excel and
the model recalculates, including the sensitivity grids (each grid cell is a complete
self-contained DCF/IRR formula).

## Verification

`npm test`:
- `engine.test.mjs` — hand-checked identities for every engine (balance sheet ties, FCFE
  identity, Hamada roundtrip, LBO bridge identity, hurdle-floor IRR, OLS vs hand-computed
  slope, IPO mechanics).
- `excel.test.mjs` — workbook structure: every formula reference resolves to a non-empty cell.
- `excel-recalc.test.mjs` — the exported workbook is recalculated from inputs alone with
  HyperFormula and compared to the JS engines (matches to 1e-9), proving the export is live.
- `excel-variants.test.mjs` — same under edge configs (3/10 years, custom per-year arrays,
  no mid-year, USD/Mn, early exit).
- `comps.test.mjs` — the comparable-companies module on synthetic data: every derived line
  on every input page re-derived by hand (LTM bridge, adjusted income statement and its tax
  effect, treasury stock method, balance-sheet ties, EV bridge, each multiple against its
  own metric row, returns, credit statistics, growth), then the exported workbook
  recalculated from its inputs alone and compared cell-by-cell to the engine — ~3,200
  recalculated cells across the company pages, both benchmarking pages, the output page,
  the List and the implied-price block, plus an edit-propagation check, a guard that every
  group banner is written (including groups past column Z), and a guard that an NM multiple
  is excluded from the statistics in both the engine and the workbook.
- `paste.test.mjs` — clipboard import: number formats (thousands separators, accounting
  negatives, currency symbols, percent, the various empty markers), label matching, the
  grid parser (auto-detected target block, column offsets, rows held back or reported
  unmatched, blank cells preserving existing values) and the wide parser (period suffixes,
  bare-column defaults, tier resolution, nameless rows dropped), plus the JSON round-trip
  private companies are entered and shared through.
