import React, { useEffect, useState, lazy, Suspense } from 'react';
import { DEFAULT_ASSUMPTIONS, mergeAssumptions } from './lib/defaults.js';
import DataEntry from './components/DataEntry.jsx';
import FetchCompany from './components/FetchCompany.jsx';
import NavRail from './components/shell/NavRail.jsx';
import TopBar from './components/shell/TopBar.jsx';
import TickerStrip from './components/shell/TickerStrip.jsx';
import Dock from './components/shell/Dock.jsx';
import { updateExistingCompany } from './lib/companyStore.js';
import { initScrollReveal } from './lib/reveal.js';
import { ASSUME_EVENT, flashAssumption } from './lib/assume.js';
import { SCENARIOS, applyScenario } from './lib/engine/scenario.js';
import { useValuationSummary } from './lib/valuations.js';
import { CompanyPanel, DriversPanel, WaccPanel } from './panels.jsx';
import {
  TerminalValuePanel, FinancingPolicyPanel, LboTransactionPanel, LboDebtPanel,
  PeerSetPanel, CompsTargetPanel, DealSetPanel, PrecTargetPanel,
  IpoPricingPanel, IpoStructurePanel, KeyLeversPanel, DisplayPanel,
} from './panels/methodPanels.jsx';
import SummaryTab from './tabs/SummaryTab.jsx';
import DcfTab from './tabs/DcfTab.jsx';
import ThreeStatementTab from './tabs/ThreeStatementTab.jsx';
import LboTab from './tabs/LboTab.jsx';
import CompsTab from './tabs/CompsTab.jsx';
import RegressionTab from './tabs/RegressionTab.jsx';
import PrecedentTab from './tabs/PrecedentTab.jsx';
import IpoTab from './tabs/IpoTab.jsx';
const ChartsTab = lazy(() => import('./tabs/ChartsTab.jsx')); // echarts loads only when the Charts view opens
const RatioTab = lazy(() => import('./tabs/RatioTab.jsx'));

const STORAGE_KEY = 'valuation-studio-v1';
const UI_KEY = 'valuation-studio-ui-v1';

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    // merge over defaults so new fields added in updates don't break old saves
    return mergeAssumptions(JSON.parse(raw));
  } catch {
    return null;
  }
}

function loadUi() {
  try {
    return JSON.parse(localStorage.getItem(UI_KEY)) || {};
  } catch {
    return {};
  }
}

function deepSet(obj, path, value) {
  const keys = path.split('.');
  const next = { ...obj };
  let cur = next;
  for (let i = 0; i < keys.length - 1; i++) {
    cur[keys[i]] = Array.isArray(cur[keys[i]]) ? cur[keys[i]].slice() : { ...cur[keys[i]] };
    cur = cur[keys[i]];
  }
  const last = keys[keys.length - 1];
  // functional updates read the CURRENT value — required for async writers
  // (e.g. Yahoo peer fetch resolving after the user kept editing)
  cur[last] = typeof value === 'function' ? value(cur[last]) : value;
  return next;
}

const TABS = [
  { id: 'summary', label: 'Summary', el: SummaryTab },
  { id: 'dcf', label: 'DCF', el: DcfTab },
  { id: 'ts', label: '3-Statement', el: ThreeStatementTab },
  { id: 'ratios', label: 'Ratios', el: RatioTab },
  { id: 'lbo', label: 'LBO', el: LboTab },
  { id: 'comps', label: 'Comps & Regression', el: CompsTab },
  { id: 'reg', label: 'Regression Lab', el: RegressionTab },
  { id: 'prec', label: 'Precedent', el: PrecedentTab },
  { id: 'ipo', label: 'IPO', el: IpoTab },
  { id: 'charts', label: 'Charts', el: ChartsTab },
];

/**
 * Which assumption panels the dock shows per view: each method gets ONLY its
 * own panels plus the shared inputs its engine genuinely consumes (Display &
 * Period stays at the bottom everywhere). Key Levers — the cross-method
 * what-if sliders — appear only on the cross-method views (Summary, Charts).
 */
const DOCK_PANELS = {
  summary: [CompanyPanel, DriversPanel, WaccPanel],
  dcf: [DriversPanel, WaccPanel, TerminalValuePanel, (p) => <FinancingPolicyPanel {...p} full={false} />, CompanyPanel],
  ts: [DriversPanel, FinancingPolicyPanel, CompanyPanel],
  ratios: [CompanyPanel, DriversPanel, FinancingPolicyPanel],
  lbo: [LboTransactionPanel, LboDebtPanel, DriversPanel, CompanyPanel],   // company: tax rate + shares/net debt for the LBO floor
  comps: [PeerSetPanel, CompsTargetPanel, DriversPanel, CompanyPanel],    // drivers: NTM revenue/EBITDA the multiples apply to
  reg: [PeerSetPanel, DriversPanel, CompanyPanel],                        // drivers: the target's derived x-values + NTM metrics
  prec: [DealSetPanel, PrecTargetPanel, DriversPanel, CompanyPanel],      // drivers: LTM revenue/EBITDA the deal multiples apply to
  ipo: [IpoPricingPanel, IpoStructurePanel, DriversPanel, CompanyPanel],  // drivers: NTM earnings/EBITDA the pricing basis uses
  charts: [DriversPanel, WaccPanel, CompanyPanel],
};
/** Views that get the cross-method Key Levers panel on top. */
const KEY_LEVER_VIEWS = new Set(['summary', 'charts']);

export default function App() {
  const [a, setA] = useState(() => {
    const base = load() || DEFAULT_ASSUMPTIONS;
    const sc = new URLSearchParams(window.location.search).get('scenario');
    return SCENARIOS[sc] ? { ...base, settings: { ...base.settings, scenario: sc } } : base;
  });
  const [view, setView] = useState(() => {
    const q = new URLSearchParams(window.location.search);
    const t = q.get('view') || q.get('tab');
    if (TABS.some((x) => x.id === t)) return t;
    return loadUi().view && TABS.some((x) => x.id === loadUi().view) ? loadUi().view : 'summary';
  });
  const [dockOpen, setDockOpen] = useState(() => loadUi().dockOpen ?? window.innerWidth > 1280);
  const [railCollapsed, setRailCollapsed] = useState(() => loadUi().railCollapsed ?? window.innerWidth < 1500);
  const [exporting, setExporting] = useState(false);
  const [dataOpen, setDataOpen] = useState(false);
  const [fetchOpen, setFetchOpen] = useState(false);   // false | { symbol }

  const summary = useValuationSummary(a);
  const scenario = a.settings.scenario || 'base';

  // Apple-style scroll reveal: view sections glide in as they enter the viewport
  useEffect(() => initScrollReveal(), []);

  // once a company is saved in the library, every edit keeps it up to date
  useEffect(() => {
    const t = setTimeout(() => updateExistingCompany(a), 800);
    return () => clearTimeout(t);
  }, [a]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(a));
    } catch { /* private mode etc. */ }
  }, [a]);

  useEffect(() => {
    try {
      localStorage.setItem(UI_KEY, JSON.stringify({ view, dockOpen, railCollapsed }));
    } catch { /* ignore */ }
    // deep-linkable views without page reloads
    const url = new URL(window.location);
    url.searchParams.set('view', view);
    url.searchParams.delete('tab');
    window.history.replaceState(null, '', url);
  }, [view, dockOpen, railCollapsed]);

  // charts dispatch this when a series is clicked: open the dock, flash the driving slider
  useEffect(() => {
    const onAssume = (e) => {
      setDockOpen(true);
      setTimeout(() => flashAssumption(e.detail), 280); // wait for the dock slide-in
    };
    window.addEventListener(ASSUME_EVENT, onAssume);
    return () => window.removeEventListener(ASSUME_EVENT, onAssume);
  }, []);

  // keyboard: 1-9 jump to a view, A toggles the assumptions dock
  useEffect(() => {
    const onKey = (e) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= TABS.length) {
        setView(TABS[n - 1].id);
      } else if (e.key === 'a' || e.key === 'A') {
        setDockOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const set = (path, value) => setA((prev) => deepSet(prev, path, value));

  const onExport = async (method = 'full') => {
    setExporting(true);
    try {
      // lazy-load so ExcelJS stays out of the main bundle; export what you see (active scenario)
      const { exportToExcel } = await import('./lib/excel/exportExcel.js');
      const am = applyScenario(a);
      const named = scenario === 'base' ? am : { ...am, company: { ...am.company, name: `${am.company.name} (${SCENARIOS[scenario].label})` } };
      await exportToExcel(named, method);
    } catch (e) {
      console.error(e);
      alert(`Excel export failed: ${e.message}`);
    } finally {
      setExporting(false);
    }
  };

  const onReset = () => {
    if (confirm('Reset every assumption to defaults? Your current inputs will be lost.')) {
      setA(DEFAULT_ASSUMPTIONS);
    }
  };

  const activeTab = TABS.find((t) => t.id === view);
  const Active = activeTab.el;
  const dockPanels = DOCK_PANELS[view] || [];

  return (
    <>
      <div className={`workspace${railCollapsed ? ' rail-min' : ''}${dockOpen ? ' dock-on' : ''}`}>
        <NavRail
          tabs={TABS}
          active={view}
          onSelect={setView}
          collapsed={railCollapsed}
          onToggleCollapse={() => setRailCollapsed(!railCollapsed)}
        />

        <div className="stage">
          <TopBar
            a={a}
            set={set}
            setA={setA}
            onExport={onExport}
            exporting={exporting}
            onFetch={(symbol) => setFetchOpen({ symbol })}
            onData={() => setDataOpen(true)}
            onReset={onReset}
            dockOpen={dockOpen}
            onToggleDock={() => setDockOpen(!dockOpen)}
          />

          <TickerStrip summary={summary} a={a} activeView={view} onSelect={setView} />

          {scenario !== 'base' && (
            <div className="warn scen-warn">
              {SCENARIOS[scenario].label} case active — growth {SCENARIOS[scenario].growth > 0 ? '+' : ''}{SCENARIOS[scenario].growth}pp,
              margin {SCENARIOS[scenario].margin > 0 ? '+' : ''}{SCENARIOS[scenario].margin}pp,
              exit multiples {SCENARIOS[scenario].mult > 0 ? '+' : ''}{SCENARIOS[scenario].mult}x,
              terminal growth {SCENARIOS[scenario].tg > 0 ? '+' : ''}{SCENARIOS[scenario].tg}pp,
              ERP {SCENARIOS[scenario].erp > 0 ? '+' : ''}{SCENARIOS[scenario].erp}pp.
              Dock inputs show your base case; outputs and Excel export reflect the scenario.
            </div>
          )}

          <Suspense fallback={<div className="view" style={{ padding: '60px 30px', color: 'var(--faint)' }}>Loading charts…</div>}>
            <Active key={`${view}-${scenario}`} a={a} set={set} />
          </Suspense>
        </div>

        <Dock open={dockOpen} title={activeTab.label} onClose={() => setDockOpen(false)}>
          {KEY_LEVER_VIEWS.has(view) && <KeyLeversPanel a={a} set={set} />}
          {dockPanels.map((P, i) => <P key={`${view}-${i}`} a={a} set={set} />)}
          <DisplayPanel a={a} set={set} setA={setA} />
        </Dock>
      </div>

      {dataOpen && (
        <DataEntry
          a={a}
          initialMethod={{ summary: 'all', dcf: 'dcf', ts: 'ts', ratios: 'ts', lbo: 'lbo', comps: 'comps', reg: 'reg', prec: 'prec', ipo: 'ipo', charts: 'all' }[view] || 'all'}
          onClose={() => setDataOpen(false)}
          onApply={(next) => { setA(next); setDataOpen(false); }}
        />
      )}
      {fetchOpen && (
        <FetchCompany
          a={a}
          symbol={fetchOpen.symbol}
          onClose={() => setFetchOpen(false)}
          onApply={(next) => { setA(next); setFetchOpen(false); }}
        />
      )}
    </>
  );
}
