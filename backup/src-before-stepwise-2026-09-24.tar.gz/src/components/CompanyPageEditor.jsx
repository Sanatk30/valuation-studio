import React, { useMemo, useState } from 'react';
import { computeCompany, validateCompany, P } from '../lib/engine/compsCo.js';
import { fmtNum, fmtPct, fmtPrice, fmtX, CURRENCIES, UNITS } from '../lib/format.js';
import PasteDialog from './PasteDialog.jsx';

/**
 * One company's input page, in the layout of the 3E "CompCo" sheet:
 * reported income statement with the LTM bridge, non-recurring adjustments,
 * cash-flow data, a two-column balance sheet with its check, the treasury-method
 * share build, consensus estimates, and the multiples/ratios they produce.
 *
 * Blue-dashed cells are inputs; everything else recalculates as you type.
 */

const PERIOD_HEADS = ['FY-2', 'FY-1', 'FY0', 'Prior stub', 'Current stub', 'LTM'];

export default function CompanyPageEditor({ co, settings, tiers, onChange, onDelete, readOnly }) {
  const [pasting, setPasting] = useState(false);
  const page = useMemo(() => computeCompany(co), [co]);
  const issues = useMemo(() => validateCompany(page), [page]);
  const locale = CURRENCIES[settings.currency].locale;
  const sym = CURRENCIES[settings.currency].symbol;
  const unit = UNITS[settings.unit];

  const set = (patch) => onChange({ ...co, ...patch });
  const setIn = (group, key, idx, v) => {
    const arr = [...(co[group][key] || [])];
    arr[idx] = v;
    set({ [group]: { ...co[group], [key]: arr } });
  };
  const setEst = (key, idx, v) => {
    const arr = [...(co.est[key] || [])];
    arr[idx] = v;
    set({ est: { ...co.est, [key]: arr } });
  };

  const money = (v) => (isFinite(v) ? fmtNum(v, 1, locale) : 'NA');
  const pct = (v) => (isFinite(v) ? fmtPct(v * 100, 1) : 'NA');
  const px = (v) => (isFinite(v) ? fmtPrice(v, settings, 2) : 'NA');
  const x = (v) => (isFinite(v) ? fmtX(v, 2) : 'NA');

  const Num = ({ value, onSet, step = 1, wide }) => (
    <input
      className="cp-in" type="number" step={step} value={Number.isFinite(value) ? value : 0}
      disabled={readOnly} style={wide ? { width: '100%' } : undefined}
      onChange={(e) => onSet(e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)}
    />
  );
  const Txt = ({ value, onSet, ph }) => (
    <input className="cp-in txt" value={value ?? ''} placeholder={ph} disabled={readOnly} onChange={(e) => onSet(e.target.value)} />
  );

  /** An income-statement / cash-flow line: five editable periods + derived LTM. */
  const InRow = ({ label, group, k, step = 1, indent }) => (
    <tr>
      <td className={indent ? 'sub' : ''}>{label}</td>
      {[0, 1, 2, 3, 4].map((i) => (
        <td key={i}><Num value={co[group][k]?.[i]} step={step} onSet={(v) => setIn(group, k, i, v)} /></td>
      ))}
      <td className="calc">{money(page[group === 'is' ? 'is' : group][k][P.LTM])}</td>
    </tr>
  );
  /** A derived line across all six periods. */
  const CalcRow = ({ label, vals, fmt = money, bold, indent }) => (
    <tr className={bold ? 'bold' : indent ? 'sub' : ''}>
      <td>{label}</td>
      {vals.map((v, i) => <td key={i} className="calc">{fmt(v)}</td>)}
    </tr>
  );

  const errs = issues.filter((i) => i.level === 'error');
  const warns = issues.filter((i) => i.level === 'warn');

  return (
    <div className="cp">
      <div className="cp-head">
        <div>
          <div className="cp-title">{co.name || 'Unnamed'} {co.ticker ? <span className="cp-tick">({co.exchange || '—'}:{co.ticker})</span> : null}</div>
          <div className="cp-sub">Input page · {sym} in {unit}, except per share data</div>
        </div>
        <div className="cp-badges">
          {errs.length > 0 && <span className="cp-badge err">{errs.length} error{errs.length > 1 ? 's' : ''}</span>}
          {warns.length > 0 && <span className="cp-badge warn">{warns.length} incomplete</span>}
          {!errs.length && !warns.length && <span className="cp-badge ok">complete</span>}
          {!readOnly && <button className="btn sm" title="Paste a block of financials straight out of Excel" onClick={() => setPasting(true)}>Paste from Excel</button>}
          {onDelete && !readOnly && <button className="peer-del" title="Remove this company" onClick={onDelete}>×</button>}
        </div>
      </div>

      {pasting && (
        <PasteDialog mode="grid" co={co} onApply={(next) => onChange(next)} onClose={() => setPasting(false)} />
      )}

      {issues.length > 0 && (
        <ul className="cp-issues">
          {issues.map((it, i) => <li key={i} className={it.level}>{it.msg}</li>)}
        </ul>
      )}

      {/* ---------------- general + market ---------------- */}
      <div className="cp-grid2">
        <div>
          <h4 className="cp-h">General information</h4>
          <table className="fin cp-kv"><tbody>
            <tr><td>Company name</td><td><Txt value={co.name} onSet={(v) => set({ name: v })} /></td></tr>
            <tr><td>Ticker</td><td><Txt value={co.ticker} onSet={(v) => set({ ticker: v })} /></td></tr>
            <tr><td>Stock exchange</td><td><Txt value={co.exchange} onSet={(v) => set({ exchange: v })} /></td></tr>
            {tiers && (
              <tr><td>Tier</td><td>
                <select className="cp-in txt" disabled={readOnly} value={co.tierId ?? ''} onChange={(e) => set({ tierId: e.target.value || null })}>
                  <option value="">— unassigned —</option>
                  {tiers.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </td></tr>
            )}
            <tr><td>Fiscal year ending (FY0)</td><td><input className="cp-in txt" type="date" disabled={readOnly} value={co.fyEnd} onChange={(e) => set({ fyEnd: e.target.value })} /></td></tr>
            <tr><td>Current stub ending</td><td><input className="cp-in txt" type="date" disabled={readOnly} value={co.stubEnd} onChange={(e) => set({ stubEnd: e.target.value })} /></td></tr>
            <tr><td>Moody's rating</td><td><Txt value={co.moodys} onSet={(v) => set({ moodys: v })} /></td></tr>
            <tr><td>S&amp;P rating</td><td><Txt value={co.sp} onSet={(v) => set({ sp: v })} /></td></tr>
            <tr><td>Predicted beta</td><td><Num value={co.beta} step={0.01} onSet={(v) => set({ beta: v })} /></td></tr>
            <tr><td>Marginal tax rate (%)</td><td><Num value={co.taxRate} step={0.1} onSet={(v) => set({ taxRate: v })} /></td></tr>
            <tr><td>Long-term growth (%)</td><td><Num value={isFinite(co.ltGrowth) ? co.ltGrowth : 0} step={0.5} onSet={(v) => set({ ltGrowth: v })} /></td></tr>
            <tr><td>Business description</td><td><Txt value={co.description} onSet={(v) => set({ description: v })} ph="[to come]" /></td></tr>
          </tbody></table>
        </div>

        <div>
          <h4 className="cp-h">Market data &amp; enterprise value</h4>
          <table className="fin cp-kv"><tbody>
            <tr><td>Current price</td><td><Num value={co.price} step={0.05} onSet={(v) => set({ price: v })} /></td></tr>
            <tr className="sub"><td>% of 52-week high</td><td className="calc">{pct(page.pctOf52wHigh)}</td></tr>
            <tr><td>52-week high</td><td><Num value={co.high52} step={0.05} onSet={(v) => set({ high52: v })} /></td></tr>
            <tr><td>52-week low</td><td><Num value={co.low52} step={0.05} onSet={(v) => set({ low52: v })} /></td></tr>
            <tr><td>Dividend per share (MRQ)</td><td><Num value={co.dpsMRQ} step={0.05} onSet={(v) => set({ dpsMRQ: v })} /></td></tr>
            <tr><td>Fully diluted shares</td><td className="calc">{fmtNum(page.shares.fullyDiluted, 3, locale)}</td></tr>
            <tr className="bold"><td>Equity value</td><td className="calc">{money(page.equityValue)}</td></tr>
            <tr className="sub"><td>Plus: total debt</td><td className="calc">{money(page.bs.debt[1])}</td></tr>
            <tr className="sub"><td>Plus: preferred stock</td><td className="calc">{money(page.bs.preferred[1])}</td></tr>
            <tr className="sub"><td>Plus: noncontrolling interest</td><td className="calc">{money(page.bs.nci[1])}</td></tr>
            <tr className="sub"><td>Less: cash &amp; equivalents</td><td className="calc neg">{money(-page.bs.cash[1])}</td></tr>
            <tr className="bold"><td>Enterprise value</td><td className="calc">{money(page.enterpriseValue)}</td></tr>
          </tbody></table>
        </div>
      </div>

      {/* ---------------- income statement ---------------- */}
      <h4 className="cp-h">Reported income statement <span className="cp-note">LTM = FY0 + current stub − prior stub</span></h4>
      <div className="tablewrap">
        <table className="fin cp-per">
          <thead><tr><th /> {PERIOD_HEADS.map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>
            <InRow label="Sales" group="is" k="sales" step={10} />
            <InRow label="COGS (incl. D&A)" group="is" k="cogs" step={10} />
            <CalcRow label="Gross profit" vals={page.grossProfit} bold />
            <InRow label="SG&A" group="is" k="sga" step={5} />
            <InRow label="Other expense / (income)" group="is" k="otherExp" step={1} />
            <CalcRow label="EBIT" vals={page.ebit} bold />
            <InRow label="Interest expense, net" group="is" k="interest" step={1} />
            <CalcRow label="Pre-tax income" vals={page.pretax} bold />
            <InRow label="Income taxes" group="is" k="taxes" step={1} />
            <InRow label="Noncontrolling interest" group="is" k="nci" step={1} />
            <InRow label="Preferred dividends" group="is" k="prefDiv" step={1} />
            <CalcRow label="Net income" vals={page.netIncome} bold />
            <CalcRow label="Effective tax rate" vals={page.effTaxRate} fmt={pct} indent />
            <InRow label="Weighted avg. diluted shares" group="is" k="dilutedShares" step={0.01} />
            <CalcRow label="Diluted EPS" vals={page.eps} fmt={px} />
          </tbody>
        </table>
      </div>

      {/* ---------------- adjusted income statement ---------------- */}
      <h4 className="cp-h">Adjusted income statement <span className="cp-note">non-recurring items added back, tax-effected at the marginal rate</span></h4>
      <div className="tablewrap">
        <table className="fin cp-per">
          <thead><tr><th /> {PERIOD_HEADS.map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>
            <InRow label="Non-recurring items in COGS" group="adj" k="nrCogs" step={1} />
            <CalcRow label="Adj. gross profit" vals={page.adjGrossProfit} bold />
            <CalcRow label="% margin" vals={page.grossMargin} fmt={pct} indent />
            <InRow label="Other non-recurring items" group="adj" k="nrOther" step={1} />
            <CalcRow label="Adjusted EBIT" vals={page.adjEbit} bold />
            <CalcRow label="% margin" vals={page.ebitMargin} fmt={pct} indent />
            <CalcRow label="Adjusted EBITDA" vals={page.adjEbitda} bold />
            <CalcRow label="% margin" vals={page.ebitdaMargin} fmt={pct} indent />
            <InRow label="Non-operating non-recurring" group="adj" k="nrNonOp" step={1} />
            <CalcRow label="Tax adjustment" vals={page.taxAdjustment} indent />
            <CalcRow label="Adjusted net income" vals={page.adjNetIncome} bold />
            <CalcRow label="% margin" vals={page.netMargin} fmt={pct} indent />
            <CalcRow label="Adjusted diluted EPS" vals={page.adjEps} fmt={px} bold />
          </tbody>
        </table>
      </div>

      {/* ---------------- cash flow ---------------- */}
      <h4 className="cp-h">Cash flow statement data</h4>
      <div className="tablewrap">
        <table className="fin cp-per">
          <thead><tr><th /> {PERIOD_HEADS.map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>
            <InRow label="Cash from operations" group="cf" k="cfo" step={10} />
            <InRow label="Capital expenditures" group="cf" k="capex" step={5} />
            <CalcRow label="% sales" vals={page.capexPctSales} fmt={pct} indent />
            <CalcRow label="Free cash flow" vals={page.fcf} bold />
            <CalcRow label="% margin" vals={page.fcfMargin} fmt={pct} indent />
            <CalcRow label="FCF / share" vals={page.fcfPerShare} fmt={px} />
            <InRow label="Depreciation & amortization" group="cf" k="da" step={5} />
            <CalcRow label="% sales" vals={page.daPctSales} fmt={pct} indent />
          </tbody>
        </table>
      </div>

      {/* ---------------- balance sheet & share build ---------------- */}
      <div className="cp-grid2">
        <div>
          <h4 className="cp-h">Balance sheet data</h4>
          <table className="fin cp-kv3">
            <thead><tr><th /><th>Prior</th><th>Current</th></tr></thead>
            <tbody>
              {[
                ['Cash and cash equivalents', 'cash'], ['Accounts receivable', 'ar'],
                ['Inventories', 'inventory'], ['Prepaids and other current assets', 'prepaid'],
              ].map(([lab, k]) => (
                <tr key={k}><td>{lab}</td>{[0, 1].map((i) => <td key={i}><Num value={co.bs[k]?.[i]} step={10} onSet={(v) => setIn('bs', k, i, v)} /></td>)}</tr>
              ))}
              <tr className="bold"><td>Total current assets</td>{page.bs.totalCurrentAssets.map((v, i) => <td key={i} className="calc">{money(v)}</td>)}</tr>
              {[['Property, plant & equipment, net', 'ppe'], ['Goodwill and intangibles', 'goodwill'], ['Other assets', 'otherAssets']].map(([lab, k]) => (
                <tr key={k}><td>{lab}</td>{[0, 1].map((i) => <td key={i}><Num value={co.bs[k]?.[i]} step={10} onSet={(v) => setIn('bs', k, i, v)} /></td>)}</tr>
              ))}
              <tr className="bold"><td>Total assets</td>{page.bs.totalAssets.map((v, i) => <td key={i} className="calc">{money(v)}</td>)}</tr>
              {[['Accounts payable', 'ap'], ['Accrued liabilities', 'accrued'], ['Other current liabilities', 'otherCurLiab']].map(([lab, k]) => (
                <tr key={k}><td>{lab}</td>{[0, 1].map((i) => <td key={i}><Num value={co.bs[k]?.[i]} step={10} onSet={(v) => setIn('bs', k, i, v)} /></td>)}</tr>
              ))}
              <tr className="bold"><td>Total current liabilities</td>{page.bs.totalCurrentLiab.map((v, i) => <td key={i} className="calc">{money(v)}</td>)}</tr>
              {[['Total debt', 'debt'], ['Other long-term liabilities', 'otherLTLiab']].map(([lab, k]) => (
                <tr key={k}><td>{lab}</td>{[0, 1].map((i) => <td key={i}><Num value={co.bs[k]?.[i]} step={10} onSet={(v) => setIn('bs', k, i, v)} /></td>)}</tr>
              ))}
              <tr className="bold"><td>Total liabilities</td>{page.bs.totalLiabilities.map((v, i) => <td key={i} className="calc">{money(v)}</td>)}</tr>
              {[['Noncontrolling interest', 'nci'], ['Preferred stock', 'preferred'], ["Shareholders' equity", 'equity']].map(([lab, k]) => (
                <tr key={k}><td>{lab}</td>{[0, 1].map((i) => <td key={i}><Num value={co.bs[k]?.[i]} step={10} onSet={(v) => setIn('bs', k, i, v)} /></td>)}</tr>
              ))}
              <tr className="bold"><td>Total liabilities and equity</td>{page.bs.totalLiabEquity.map((v, i) => <td key={i} className="calc">{money(v)}</td>)}</tr>
              <tr className={Math.abs(page.bs.check[1]) > 1e-6 ? 'bold cp-bad' : 'bold'}>
                <td>Balance check</td>{page.bs.check.map((v, i) => <td key={i} className="calc">{fmtNum(v, 2, locale)}</td>)}
              </tr>
            </tbody>
          </table>
        </div>

        <div>
          <h4 className="cp-h">Fully diluted shares <span className="cp-note">treasury stock method</span></h4>
          <table className="fin cp-kv"><tbody>
            <tr><td>Basic shares outstanding</td><td><Num value={co.basicShares} step={0.01} onSet={(v) => set({ basicShares: v })} /></td></tr>
            <tr className="sub"><td>Plus: shares from in-the-money options</td><td className="calc">{fmtNum(page.shares.itmShares, 3, locale)}</td></tr>
            <tr className="sub"><td>Less: shares repurchased</td><td className="calc neg">{fmtNum(page.shares.repurchased, 3, locale)}</td></tr>
            <tr><td>Net new shares from options</td><td className="calc">{fmtNum(page.shares.netNew, 3, locale)}</td></tr>
            <tr className="sub"><td>Plus: shares from convertibles</td><td className="calc">{fmtNum(page.shares.convShares, 3, locale)}</td></tr>
            <tr className="bold"><td>Fully diluted shares outstanding</td><td className="calc">{fmtNum(page.shares.fullyDiluted, 3, locale)}</td></tr>
          </tbody></table>

          <h5 className="cp-h5">Options / warrants</h5>
          <table className="fin cp-kv4">
            <thead><tr><th>Tranche</th><th>Shares</th><th>Strike</th><th>ITM shares</th><th /></tr></thead>
            <tbody>
              {(co.options || []).map((o, i) => (
                <tr key={i}>
                  <td>Tranche {i + 1}</td>
                  <td><Num value={o.shares} step={0.001} onSet={(v) => set({ options: co.options.map((r, j) => (j === i ? { ...r, shares: v } : r)) })} /></td>
                  <td><Num value={o.strike} step={1} onSet={(v) => set({ options: co.options.map((r, j) => (j === i ? { ...r, strike: v } : r)) })} /></td>
                  <td className="calc">{fmtNum(page.shares.options[i]?.itm ?? 0, 3, locale)}</td>
                  <td>{!readOnly && <button className="peer-del" onClick={() => set({ options: co.options.filter((_, j) => j !== i) })}>×</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!readOnly && <button className="btn sm" onClick={() => set({ options: [...(co.options || []), { shares: 0, strike: 0 }] })}>+ Add tranche</button>}

          <h5 className="cp-h5">Convertible securities</h5>
          <table className="fin cp-kv4">
            <thead><tr><th>Issue</th><th>Amount</th><th>Conv. price</th><th>New shares</th><th /></tr></thead>
            <tbody>
              {(co.converts || []).map((c, i) => (
                <tr key={i}>
                  <td>Issue {i + 1}</td>
                  <td><Num value={c.amount} step={5} onSet={(v) => set({ converts: co.converts.map((r, j) => (j === i ? { ...r, amount: v } : r)) })} /></td>
                  <td><Num value={c.price} step={1} onSet={(v) => set({ converts: co.converts.map((r, j) => (j === i ? { ...r, price: v } : r)) })} /></td>
                  <td className="calc">{fmtNum(page.shares.converts[i]?.newShares ?? 0, 3, locale)}</td>
                  <td>{!readOnly && <button className="peer-del" onClick={() => set({ converts: co.converts.filter((_, j) => j !== i) })}>×</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!readOnly && <button className="btn sm" onClick={() => set({ converts: [...(co.converts || []), { amount: 0, price: 0 }] })}>+ Add issue</button>}
        </div>
      </div>

      {/* ---------------- estimates & multiples ---------------- */}
      <h4 className="cp-h">Consensus estimates &amp; trading multiples</h4>
      <div className="tablewrap">
        <table className="fin cp-per">
          <thead><tr><th /><th>LTM</th><th>NFY</th><th>NFY+1</th><th>NFY+2</th></tr></thead>
          <tbody>
            {[
              ['EV / Sales', 'evSales', 'sales', money, 10],
              ['EV / EBITDA', 'evEbitda', 'ebitda', money, 5],
              ['EV / EBIT', 'evEbit', 'ebit', money, 5],
              ['P / E', 'pe', 'eps', px, 0.5],
              ['P / FCF', 'pFcf', 'fcfPerShare', px, 0.5],
            ].map(([label, mk, ek, fmt, step]) => (
              <React.Fragment key={mk}>
                <tr className="bold">
                  <td>{label}</td>
                  {page.multiples[mk].values.map((v, i) => <td key={i} className="calc">{x(v)}</td>)}
                </tr>
                <tr className="sub">
                  <td>Metric</td>
                  <td className="calc">{fmt(page.multiples[mk].metric[0])}</td>
                  {[0, 1, 2].map((i) => <td key={i}><Num value={co.est[ek]?.[i]} step={step} onSet={(v) => setEst(ek, i, v)} /></td>)}
                </tr>
              </React.Fragment>
            ))}
            <tr className="bold"><td>FCF yield</td>{page.multiples.fcfYield.values.map((v, i) => <td key={i} className="calc">{pct(v)}</td>)}</tr>
          </tbody>
        </table>
      </div>

      {/* ---------------- ratios ---------------- */}
      <div className="cp-grid2">
        <div>
          <h4 className="cp-h">LTM return on investment</h4>
          <table className="fin cp-kv"><tbody>
            <tr><td>Return on invested capital</td><td className="calc">{pct(page.roic)}</td></tr>
            <tr><td>Return on equity</td><td className="calc">{pct(page.roe)}</td></tr>
            <tr><td>Return on assets</td><td className="calc">{pct(page.roa)}</td></tr>
            <tr><td>Implied annual dividend yield</td><td className="calc">{pct(page.dividendYield)}</td></tr>
          </tbody></table>
          <h4 className="cp-h">Growth rates</h4>
          <table className="fin cp-kv4">
            <thead><tr><th /><th>Sales</th><th>EBITDA</th><th>FCF/sh.</th><th>EPS</th></tr></thead>
            <tbody>
              {[['Historical 1-year', 'hist1'], ['Historical 2-year CAGR', 'hist2'], ['Estimated 1-year', 'est1'], ['Estimated 2-year CAGR', 'est2']].map(([lab, k]) => (
                <tr key={k}><td>{lab}</td>{['sales', 'ebitda', 'fcf', 'eps'].map((g) => <td key={g} className="calc">{pct(page.growth[g][k])}</td>)}</tr>
              ))}
              <tr><td>Long-term</td><td className="calc" colSpan={4}>{pct(page.growth.longTerm)}</td></tr>
            </tbody>
          </table>
        </div>
        <div>
          <h4 className="cp-h">LTM credit statistics</h4>
          <table className="fin cp-kv"><tbody>
            <tr><td>Debt / total capitalization</td><td className="calc">{pct(page.credit.debtToTotalCap)}</td></tr>
            <tr><td>Total debt / EBITDA</td><td className="calc">{x(page.credit.debtToEbitda)}</td></tr>
            <tr><td>Net debt / EBITDA</td><td className="calc">{x(page.credit.netDebtToEbitda)}</td></tr>
            <tr><td>EBITDA / interest expense</td><td className="calc">{x(page.credit.ebitdaToInterest)}</td></tr>
            <tr><td>(EBITDA − capex) / interest</td><td className="calc">{x(page.credit.ebitdaLessCapexToInterest)}</td></tr>
            <tr><td>EBIT / interest expense</td><td className="calc">{x(page.credit.ebitToInterest)}</td></tr>
          </tbody></table>
        </div>
      </div>
    </div>
  );
}
